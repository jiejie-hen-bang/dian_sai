/*
 * Voice_deal.h

 */

#ifndef SRC_APPSW_TRICORE_APP_VOICE_DEAL_H_
#define SRC_APPSW_TRICORE_APP_VOICE_DEAL_H_

//#include "headfile.h"



short Micdata_cov(unsigned short* data1, unsigned short* data2, unsigned short point, short point1, short point2);
short Filt_Micdata_cov(unsigned short* data1, unsigned short* data2, unsigned short point, short point1, short point2);
short Data_Ave(int N);
void get_beacon(void);
void get_beacon_1(void);
void Micdata_read(void);
void FFT_distance(void);
#endif /* SRC_APPSW_TRICORE_APP_VOICE_DEAL_H_ */
