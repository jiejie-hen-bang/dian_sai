/*
 * Variable.h
 *
 *  Created on: 2020��4��8��
 *      Author: ��
 */

#ifndef SRC_APPSW_TRICORE_APP_VARIABLE_H_
#define SRC_APPSW_TRICORE_APP_VARIABLE_H_
#include "stdint.h"


//��־λ
extern unsigned char car_mod;
extern unsigned char display_mod;
extern unsigned char adjust_speed;
extern unsigned char rssi;
extern unsigned char avoid_en;
extern unsigned char count_en;
extern unsigned char change_en;
extern unsigned char beacon_state;
extern unsigned char car_state;
//extern unsigned char test_time;
extern unsigned int time_count;
extern char txt[32];

#define left 0
#define right 1
#define front 2

//����
extern unsigned int distance1;
extern unsigned int distance2;

//�ٶ��������
extern unsigned short limit_pwm;

extern short pre_speed;
extern short line_speed;
extern short near_speed;
extern short avoid_xspeed;


extern short Left_front_speed;
extern short Right_front_speed;
extern short Left_rear_speed;
extern short Right_rear_speed;

extern short Left_front_goalspeed;
extern short Right_front_goalspeed;
extern short Left_rear_goalspeed;
extern short Right_rear_goalspeed;



//��˷硢FM ������ݺ�����
extern unsigned short buff_index;
extern short delay13;
extern short delay34;
extern short distance;
extern unsigned short sample_point;
#define SAMPLE_NUB  (4096)
extern short data1[SAMPLE_NUB];
extern short data2[SAMPLE_NUB];
extern short data3[SAMPLE_NUB];
extern short data4[SAMPLE_NUB];
extern short FMdata[SAMPLE_NUB];/*
extern cfloat32 fft_x[2048];
extern cfloat32 fft_y[2048];
extern cfloat32 fft_z[2048];*/

#endif /* SRC_APPSW_TRICORE_APP_VARIABLE_H_ */
